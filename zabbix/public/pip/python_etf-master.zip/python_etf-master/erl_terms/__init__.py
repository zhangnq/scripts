from erl_terms.erl_terms_core import decode, ParseError

__all__ = ["decode", "ParseError"]
